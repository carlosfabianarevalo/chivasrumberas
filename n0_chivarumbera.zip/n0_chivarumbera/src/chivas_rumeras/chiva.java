package chivas_rumeras;

public class chiva 
{
	//-------------------------------------------------------------------
	//Atributos
	//-------------------------------------------------------------------
	private String nombre;
	private int capacidadChiva;
	private int cantidadSillas;
	private double precioHora;
	private double horasAlquiladas;
	
	//Contructor
	//-------------------------------------------------------------------
	
	public chiva (String pNombre, int pCapacidadChiva, int pCantidadSillas, double pPrecioHora, double pHorasAlquiladas )
	{
		nombre = pNombre;
		capacidadChiva = pCapacidadChiva;
		cantidadSillas = pCantidadSillas;
		precioHora = pPrecioHora;
		horasAlquiladas = pHorasAlquiladas;				
	}
	
	//--------------------------------------------------------------------
	//Metodos
	//--------------------------------------------------------------------
	public double calcularRecaudo()
	{
		return horasAlquiladas * precioHora;
	}	
	
	
	//GET
	public String getNombre()
	{
		return nombre;
	}
	
	public int getCapacidadChiva()
	{
		return capacidadChiva;
	}
	
	public int getCantidadSilla()
	{
		return cantidadSillas;
	}
	
	public double getPrecioHora()
	{
		return precioHora;
	}
	
	public double getHorasAlquiladas()
	{
		return horasAlquiladas;
	}
	
	//SET
	
	public void setNombre(String pNombre)
	{
		nombre = pNombre;	
	}
	
	public void setCapacidadChiva(int pCapacidadChiva)
	{
		capacidadChiva = pCapacidadChiva;	
	}
	
	public void setCantidadSillas(int pCantidadSillas)
	{
		cantidadSillas = pCantidadSillas;	
	}
	
	public void setPrecioHora(double pPrecioHora)
	{
		precioHora = pPrecioHora;	
	}
	
	public void setHorasAlquiladaa(double pHorasAlquilada)
	{
		horasAlquiladas = pHorasAlquilada;	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
} 
